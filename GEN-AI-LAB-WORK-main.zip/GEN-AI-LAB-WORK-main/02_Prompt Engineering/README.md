Code link :: https://colab.research.google.com/drive/1Byy1pLBFv3I69B5HhN1q-o_l64J04tud?usp=sharing

In this experiment/ session we will try to learn why good prompt/questions are important , how to frame them and basic comparison. I am using a simple mistral-7b v0.2 model quatised in gguf format. You can do this using other ways as well